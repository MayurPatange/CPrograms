#include <stdio.h>

void main(){
    int num = 10;
    int num2 = 20;
    float price = 55.677;


    printf("Here is the example\n");

    printf("this is number one = %d, \n and this is number two=%d \n and price is= %f",num,num2,price);


}