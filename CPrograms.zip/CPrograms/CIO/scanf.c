#include <stdio.h>
void main(){
    printf("Example of scanf with different datatypes");

    int Roll_number;
    float price;
    char Class;

    printf("\nEnter student Roll number: ");
    scanf("%d",&Roll_number);

    printf("\n Enter price: ");
    scanf("%f",&price);

    // printf("\n Enter Class: ");
    // scanf("%c",&Class);

    printf("Student Roll Number is : %o",Roll_number);
    printf("Student books price is : %f",price);
    // printf("Student class is : %c",Class);

  

}