// this is my proogram


#include<stdio.h>
void main()
{
        
    printf("HEllO C");
}

// this is my proogram
