// C program to print char data types.
#include <stdio.h>

int main()
{
	char a = 'a';
	char c;
    const char d = 'd';  // value can not be changed.

	printf("Value of a: %c\n", a);

	// c is assigned ASCII values
	// which corresponds to the
	// character 'c'
	// a-->97 b-->98 c-->99
	// here c will be printed
	c = 99;

	printf("Value of c: %c", c);

    // a = a-32;
    a++;
	printf("\nValue of a after increment is: %c\n", a);



	return 0;
}
