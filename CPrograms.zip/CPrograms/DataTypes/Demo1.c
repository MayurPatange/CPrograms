#include<stdio.h>
void main()
{
    const int int_const = 40;  // change is not allowed for const
    int roll_number; // decalre ;
    printf("\n roll number is = %d , %d",roll_number,int_const);

    roll_number = 20;  // initilise 

    printf("\n roll number is = %d",roll_number);

    roll_number = 30; //re initilise

    printf("\n roll number is = %d",roll_number);

    printf("End\t..\n");
}