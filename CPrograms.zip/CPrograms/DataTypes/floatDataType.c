// C Program to demonstrate use
// of Floating types
#include <stdio.h>

int main()
{
	float a = 9.0f;
	float b = 2;
    float c = 3.4;
	// 2x10^-4
	// float c = 2E-4f;
	printf("%.2f\n", a);
	printf("%f\n", b);
	printf("%f", c);

	return 0;
}
