#include<stdio.h>

void main(){

    // logical AND  &&
    int a = 133;
    int b =20;
    int c = 11;
    int d = 2;
    
    a>b ? printf("\na is greater then b") : printf("\nb is greater then a");
    
    a>c ? printf("\na is greater then c") : printf("\nc is greater then a");

    //  (1   &&   1  &&   1 ) = 1 
    ( (a>b) && (a>c) && (a>d)) ? printf("\na is greater then all") : printf("\na is less then all");



     a = 3;
     b =20;
     c = 11;
     d = 2;
//      0   ||   0   ||  1
    ( (a>b) || (a>c) ||  (a>d)) ? printf("\na is greater") : printf("\na is less then");


}