#include<stdio.h>
void main(){
    int a =10;
    int b=20;

    int c = a + b;

    printf("\naddition of two number is ,%d",a+b);
    printf("\naddition of %d and %d is = %d",a,b,c);
}