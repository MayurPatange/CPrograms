#include<stdio.h>

void main(){

    int a =10;
    int b =20;
    
    printf("\n a>b=%d \n ",(a>b));

    a>b ? printf("a is greater") : printf("b is greater");
    
    !(20%2) ? printf("\n%d",a+b) : printf("\n%d",a-b);

}