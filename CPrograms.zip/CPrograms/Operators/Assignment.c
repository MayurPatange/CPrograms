#include<stdio.h>

void main(){
    int a ,b,c;
    a = 10;
    c = 20;  // 1 
    b = a + c ;  //2  b = 30 
    b +=c;  //shorthand;  = 30+20 = 50   /// b = b + c; // = 50
    

    printf("\na value is : %d",a);
    printf("\nb value is : %d",b);
    printf("\nc value is : %d",c);


    b -=c;  //shorthand;  b = b - c;

    printf("\nb value is (-) : %d",b);

    b *=c;  //shorthand; b = b * c; //

    printf("\nb value is (*) : %d",b);

    b /=c;  //shorthand; b = b / c; //

    printf("\nb value is (/) : %d",b);

    b %=c;  //shorthand; b = b % c; //

    printf("\nb value is (%%) : %d",b);


}