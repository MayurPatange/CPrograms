#include<stdio.h>

void main(){
    // increment  

    // 1 POST INCREMENT
    int counter = 13 ;
    int counterpre = 10;
    int c= 0;
    printf("\nBefore increment counter: %d",counter);

    counter=counter+1;

    printf("\nAfter increment counter: %d",counter);

    counter++;   // counter  = counter ++ ;  //assign 1st then addition

    printf("\nAfter increment counter : %d",counter);

     // 1 Pre INCREMENT
    
    printf("\nBefore counterpre : %d",counterpre);

    ++counterpre;   // counter  = counter ++ ;  //addition 1st then assign

    printf("\nAfter increment counterpre:  %d",counterpre);  //11
    
    c = counterpre++;  // post incrememt

    printf("\nAfter increment counterpre : %d %d",c, counterpre); // 12 


    printf("\n**************************************************\n");

// Decrement 

    printf("\nBefore post Decrement counter: %d",counter);

    counter--;  // post decrement

    printf("\n After post Decrement counter: %d",counter);


    printf("\nBefore pre Decrement counter: %d",counterpre);

    --counterpre;  // post decrement

    printf("\n After pre Decrement counter: %d",counterpre);

    c = --counterpre;

    printf("\nAfter  pre Decrement c, counterpre : %d %d",c, counterpre); // 12 
    

}
