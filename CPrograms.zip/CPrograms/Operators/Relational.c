#include<stdio.h>
void main(){
    int a,b,c,d;
    a=10;
    b=20;
    printf("%d is greater then %d : %d ",a,b,a>b);
    // printf("%d is greater then %d : %d ",b,a,b>a);
    
    c = 110;
    d = 110;
    printf("\n %d is greater or equal then %d : %d ",d,c,d>=c);

    printf("%d \n is less then %d : %d ",a,b,a<b);
    printf("\n %d is less or equal then %d : %d ",d,c,d<=c);

    printf("\n%d==%d:%d",a,b,a==b);

    printf("\n%d==%d:%d",c,d,c==d);


    printf("\n%d!=%d:%d",a,b,a!=b);

    printf("\n%d!=%d:%d",c,d,c!=d);



}